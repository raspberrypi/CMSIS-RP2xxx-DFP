#include <stdint.h>

static volatile uint32_t counter = 0;


int32_t main(void)
{
	while (1) {
    counter = counter + 1;
		counter *= 3;
		counter--;
	}
}
