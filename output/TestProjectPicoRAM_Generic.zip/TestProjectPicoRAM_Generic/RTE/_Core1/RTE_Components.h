
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'test' 
 * Target:  'Core1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "rp2040.h"

/* Keil::Device:Startup:C Startup:1.0.0 */
#define RTE_DEVICE_STARTUP_RP2040    /* Device Startup for RP2040 */


#endif /* RTE_COMPONENTS_H */
